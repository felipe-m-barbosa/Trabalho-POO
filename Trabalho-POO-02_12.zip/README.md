# Trabalho-POO
Criação de jogo baseado no clássico PAC-MAN, para a disciplina de Programação Orientada a Objetos.
<br><br>
Linguagem: Java
