Pasta destinada ao desenvolvimento do trabalho.
