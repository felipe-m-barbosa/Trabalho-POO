/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elements;

import java.io.Serializable;

/**
 *
 * @author Alexandre, Alysson, Felipe, João
 */
public class Usuario implements Serializable, Comparable{

    private String nome;
    private int pontuacao;
    
    public Usuario(String nome, int pontuacao) {
        this.nome = nome;
        this.pontuacao = pontuacao;
    }
    
    public Usuario()
    {
        
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public void setPontuacao(int pontuacao) {
        this.pontuacao = pontuacao;
    }
    
    public String getNome() {
        return nome;
    }

    public int getPontuacao() {
        return pontuacao;
    }
    
    @Override
    public int compareTo(Object o){
        Usuario novoRecorde = (Usuario)o;
        if (this.pontuacao > novoRecorde.pontuacao) {
            return -1;
        }
        if (this.pontuacao < novoRecorde.pontuacao) {
            return 1;
        }
        return 0;
    }
    
}
