package control;

import elements.*;
import java.awt.Graphics;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.ImageIcon;
import utils.Som;

/**
 * Projeto de POO 2017
 * 
 * @author Alexandre, Alysson, Felipe, João
 * Baseado em material do Prof. Luiz Eduardo
 */
public class GameController {
    
    ImageIcon imageIcon;
    
    public GameController()
    {
        
    }
    
    public void drawDynamicElements(ArrayList<Element> elemArray, Graphics g){
        
        for(int i=0; i<elemArray.size(); i++){
            if (elemArray.get(i) instanceof Pacman || elemArray.get(i) instanceof Fantasma){
                elemArray.get(i).autoDraw(g);
            }
        }
    }
    
    public void processAllElements(ArrayList<Element> e, Pacman pacman, Fantasma vermelho, Fantasma rosa, Fantasma ciano, Fantasma laranja, Som som){
        if(e.isEmpty()){
            return;
        }
        
        //variavel temporaria de Element para fazer os testes
        Element eTemp;
        int i;
        
        //Pegando os fantasmas
        for(i = 1; i < e.size(); i++){
            eTemp = e.get(i);
            if(eTemp instanceof Fantasma){
                break;
            }
        }
        
        if (!isValidPosition(e, pacman)) {
            pacman.backToLastPosition();
            //pegando a direção atual
            pacman.setMovDirection(Pacman.STOP);
            som.parar();
            return;
        }
        
        
        if (!isValidPosition(e, vermelho)) {
            vermelho.backToLastPosition();
            //vamos gerar uma direção aleatorio então, já que o fantasma não pode parar
            Random random = new Random();
            int sorteio = random.nextInt(4);
            vermelho.setMovDirection(sorteio+1);
            return;
        }
        if (!isValidPosition(e, rosa)) {
            rosa.backToLastPosition();
            //vamos gerar uma direção aleatorio então, já que o fantasma não pode parar
            Random random = new Random();
            int sorteio = random.nextInt(4);
            rosa.setMovDirection(sorteio+1);
            return;
        }
        
        if (!isValidPosition(e, ciano)) {
            ciano.backToLastPosition();
            //vamos gerar uma direção aleatorio então, já que o fantasma não pode parar
            Random random = new Random();
            int sorteio = random.nextInt(4);
            ciano.setMovDirection(sorteio+1);
            return;
        }
        if (!isValidPosition(e, laranja)) {
            laranja.backToLastPosition();
            //vamos gerar uma direção aleatorio então, já que o fantasma não pode parar
            Random random = new Random();
            int sorteio = random.nextInt(4);
            laranja.setMovDirection(sorteio+1);
            return;
        }
        
        BackgroundElement elementoCoringa;  //acho que é interessante mudar o nome dessa variavel
        
        for(i = 1; i < e.size(); i++){
            eTemp = e.get(i);
            if(pacman.overlap(eTemp)){
                if(eTemp.isTransposable()){
                    if (eTemp instanceof BackgroundElement){
                        if (((BackgroundElement)eTemp).getTipo().equals("caminho")){
                            elementoCoringa = (BackgroundElement)eTemp;
                            if (elementoCoringa.getTemPacDot()){
                                elementoCoringa.setTemPacDot(false);
                                elementoCoringa.setNomeImagem("caminho_vinho.png");
                                //pacman ganha pontos
                                pacman.pontuacao = pacman.pontuacao + 10;
                                pacman.pontosParaVida += 10;
                                //Trocou a imagem. Logo, o pacman comeu a pacdot e diminui o número de pacdots.
                                Stage.numPacDots--;
                            }
                            if (elementoCoringa.getTemFruta()){
                                if(elementoCoringa.getTipoFruta() == "morango"){
                                    elementoCoringa.setTemFruta(false);
                                    elementoCoringa.setNomeImagem("caminho_vinho.png");
                                    //pacman ganha pontos
                                    pacman.pontuacao = pacman.pontuacao + 300;
                                    pacman.pontosParaVida += 300;
                                    //Trocou a imagem. Logo, o pacman comeu a fruta.
                                }
                                else{
                                    elementoCoringa.setTemFruta(false);
                                    elementoCoringa.setNomeImagem("caminho_vinho.png");
                                    //pacman ganha pontos
                                    pacman.pontuacao = pacman.pontuacao + 100;
                                    pacman.pontosParaVida += 100;
                                    //Trocou a imagem. Logo, o pacman comeu a fruta.
                                }
                            }
                        }
                        //Colisão com a powerPellet
                        if(((BackgroundElement)eTemp).getTipo().equals("powerpellet")){
                            elementoCoringa = (BackgroundElement)eTemp;
                            if (elementoCoringa.getTemPowerPallet()){
                                elementoCoringa.setTemPowerPallet(false);
                                elementoCoringa.setNomeImagem("caminho_vinho.png");
                                //pacman ganha pontos
                                pacman.pontuacao = pacman.pontuacao + 110;
                                pacman.pontosParaVida += 110;
                                //Trocou a imagem. Logo, o pacman comeu a pacdot e diminui o número de pacdots.
                                Stage.numPacDots--;
                                //precisamos ativar o poder dado pela power pellet
                                pacman.setPowerPelletComida(true);
                            }
                        }
                    }
                    else{
                        if(eTemp instanceof Fantasma){
                            //Gasta um vida
                            if(((Fantasma) eTemp).getIsMortal())
                            {
                                pacman.vidas = pacman.vidas - 1;
                                pacman.setPosition(3, 1);
                            }
                            else
                            {
                                pacman.pontuacao += 200*Math.pow(2, pacman.getFantasmasComidos());
                                pacman.pontosParaVida += 200*Math.pow(2, pacman.getFantasmasComidos());
                                pacman.setFantasmasComidos(pacman.getFantasmasComidos()+1);
                                
                                //Aqui volta o fantasma às posições originais, depois que foi comido pelo pacman
                                ((Fantasma)eTemp).setIsMortal(true);
                                switch (Stage.fase)
                                {
                                    case 0: ((Fantasma)eTemp).setPosition(12, 13);
                                        break;
                                    case 1: ((Fantasma)eTemp).setPosition(13, 13);
                                        break;
                                    case 2: ((Fantasma)eTemp).setPosition(14, 13);
                                        break;
                                }
                                
                                if (((Fantasma)eTemp).getNome().equals("Clyde"))
                                {
                                    ((Fantasma)eTemp).novaImagem("clyde_baixo.png");
                                }
                                else if(((Fantasma)eTemp).getNome().equals("Blinky"))
                                {
                                    ((Fantasma)eTemp).novaImagem("blinky_baixo.png");
                                }
                                else if(((Fantasma)eTemp).getNome().equals("Pinky"))
                                {
                                    ((Fantasma)eTemp).novaImagem("pinky_baixo.png");
                                }
                                else if(((Fantasma)eTemp).getNome().equals("Inky"))
                                {
                                    ((Fantasma)eTemp).novaImagem("inky_baixo.png");
                                }
                            }
                        }
                    }
                }
            }
        }
        
        //Optei por fazer o seguinte código nessa região pois neste ponto
        //todas as manipulações com a pontuação já foram concluídas
        //Se atingiu certa pontuação, ganha uma vida
        if (pacman.pontosParaVida > 10000)
        {
            pacman.vidas++;
            pacman.pontosParaVida = 0;
        }
        
        //Só começa a se mover depois de um tempo, que é o tempo das piscadas
        //da faixa indicativa da fase atual
        if (!Stage.mudouFaseRecentemente)
        {
            pacman.move();
            vermelho.move();
            rosa.move();
            ciano.move();
            laranja.move();
        }
    }
    
    //Testa validade da posição. Usado para testar colisões com paredes e fantasmas no modo normal.
    public boolean isValidPosition(ArrayList<Element> elemArray, Element elem){
        Element elemAux;
        for(int i = 1; i < elemArray.size(); i++){
            if(!(elemArray.get(i) instanceof Pacman))
            {
                elemAux = elemArray.get(i);
                
                if(!elemAux.isTransposable())
                    if(elemAux.overlap(elem))
                        return false;
            }
        }        
        return true;
    }
}
