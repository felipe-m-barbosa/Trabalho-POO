/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package elements;

import java.awt.Graphics;

/**
 *
 * @author Felipe
 */
public class CabecalhoSalvamento extends Element{
    private int numParedes;
    private int numCaminhos;
    private int fase;
    private long tempoPowerPellet;
    private long tempoSomeMorango;
    private long tempoSomeCereja;
    private boolean powerPelletAtiva;

    public long getTempoSomeMorango() {
        return tempoSomeMorango;
    }

    public void setTempoSomeMorango(long tempoSomeMorango) {
        this.tempoSomeMorango = tempoSomeMorango;
    }

    public long getTempoSomeCereja() {
        return tempoSomeCereja;
    }

    public void setTempoSomeCereja(long tempoSomeCereja) {
        this.tempoSomeCereja = tempoSomeCereja;
    }
    

    public int getFase() {
        return fase;
    }

    public long getTempoPowerPellet() {
        return tempoPowerPellet;
    }

    public void setTempoPowerPellet(long tempoPowerPellet) {
        this.tempoPowerPellet = tempoPowerPellet;
    }

    public boolean getPowerPelletAtiva() {
        return powerPelletAtiva;
    }

    public void setPowerPelletAtiva(boolean powerPelletAtiva) {
        this.powerPelletAtiva = powerPelletAtiva;
    }

    public void setFase(int fase) {
        this.fase = fase;
    }

    public CabecalhoSalvamento(int numParedes, int numCaminhos, int fase) {
        this.numParedes = numParedes;
        this.numCaminhos = numCaminhos;
        this.fase = fase;
    }

    public int getNumParedes() {
        return numParedes;
    }

    public void setNumParedes(int numParedes) {
        this.numParedes = numParedes;
    }

    public int getNumCaminhos() {
        return numCaminhos;
    }

    public void setNumCaminhos(int numCaminhos) {
        this.numCaminhos = numCaminhos;
    }

    @Override
    public void autoDraw(Graphics g) {
        
    }
    
    
}
