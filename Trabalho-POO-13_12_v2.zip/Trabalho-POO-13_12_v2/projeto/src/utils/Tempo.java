/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package utils;

import java.util.Calendar;

/**
 *
 * @author João Vitor
 */
public class Tempo {
    //Métodos para trabalhar com tempo
    
    //Pega a hora atual do sistema
    public Calendar getHoraAtual(){
        return Calendar.getInstance();
    }
}
